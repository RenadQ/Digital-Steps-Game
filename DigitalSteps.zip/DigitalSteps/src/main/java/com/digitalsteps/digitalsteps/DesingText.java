/*
 Renad alkahtani 
here all we need to color the text :)
 */
package com.digitalsteps.digitalsteps;
import java.io.*;

public class DesingText {
    // Declaring ANSI_RESET so that we can reset the color 
    public static final String ANSI_RESET = "\u001B[0m"; 
  
    // Declaring the color 
    // Custom declaration 
    public static final String ANSI_YELLOW = "\u001B[33m"; 
    public static final String ANSI_Black = "\u001B[30m"; 
    public static final String ANSI_Red = "\u001B[31m"; 
    public static final String ANSI_Blue = "\u001B[34m"; 
    public static final String ANSI_Purple = "\u001B[35m"; 
    public static final String ANSI_White = "\u001B[37m";
    public static final String ANSI_Cyan = "\u001B[36m"; 
     public static final String ANSI_Green = "\u001B[32m"; 
    
    //Background
     public static final String ANSI_Yellow_BACKGROUND = "\u001B[43m"; 
     public static final String ANSI_Black_BACKGROUND = "\u001B[40m";
     public static final String ANSI_RED_BACKGROUND = "\u001B[41m";
     public static final String ANSI_Blue_BACKGROUND = "\u001B[44m";
      public static final String ANSI_Purple_BACKGROUND = "\u001B[45m";
     public static final String ANSI_White_BACKGROUND = "\u001B[47m";
     public static final String ANSI_Cyan_BACKGROUND = "\u001B[46m";
      public static final String ANSI_Green_BACKGROUND = "\u001B[42m";
     
     }
     
