package com.digitalsteps.digitalsteps;
import java.util.*;
public class Intermediate extends Quiz{
    public Intermediate() {
        super();
    }


    /*private int countPointBeg;
    public Intermediate (){
        countPointBeg = 0;
    }
    public int getCountPointBeg() {
        return countPointBeg;
    }*/

    /**
     *
     * @return
     */

    public void training(){
        Scanner input = new Scanner(System.in);
        String yesOrNo;
        String expectedWord;
        String answer;

        boolean isCorrect = false;
        System.out.println("Welcome to intermediate level");
        System.out.println("Do we begin? (y/n)");
        yesOrNo=input.nextLine();
        if(yesOrNo.equalsIgnoreCase("Yes") || yesOrNo.equalsIgnoreCase("yes") || yesOrNo.equalsIgnoreCase("Y") || yesOrNo.equalsIgnoreCase("y")){
            System.out.println("----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
            System.out.println("""
                                   Lesson 3
                                   Loops""");
            System.out.println("----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
            System.out.println("""
                                   Loops can execute a block of code as long as a specified condition is reached.
                                   The for loop consists of three parts: initialization, condition, and iteration statement.
                                   1-While Loop:The while loop loops through a block of code as long as a specified condition is true
                                   In the example below, the code in the loop will run, over and over again, as long as a variable (i) is less than 5:
                                   int i = 0;
                                   while (i < 5) {
                                     System.out.println(i);
                                     i++;
                                   2-Do/While Loop
                                   This loop will execute the code block once, before checking if the condition is true, then it will repeat the loop as long as the condition is true.
                                   in the example it use a do/while loop. The loop will always be executed at least once, even if the condition is false, because the code block is executed before the condition is tested:
                                   int i = 0;
                                   do {
                                     System.out.println(i);
                                     i++;
                                   }
                                   while (i < 5);
                                   }
                                   3-For Loop
                                   When you know exactly how many times you want to loop through a block of code, use the for loop instead of a while loop
                                   The example below will print the numbers 0 to 4:
                                   for (int i = 0; i < 5; i++) {
                                     System.out.println(i);
                                   }
                                   4-Nested Loops
                                   It is also possible to place a loop inside another loop. This is called a nested loop 
                                   The "inner loop" will be executed one time for each iteration of the "outer loop"
                                   
                                   // Outer loop
                                   for (int i = 1; i <= 2; i++) {
                                     System.out.println("Outer: " + i); // Executes 2 times
                                     
                                     // Inner loop
                                     for (int j = 1; j <= 3; j++) {
                                       System.out.println(" Inner: " + j); // Executes 6 times (2 * 3)
                                     }
                                   } 
                                   Now let's move on to the questions
                                   """);
            expectedWord = "once";
            do{
                System.out.println("----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
                System.out.println("""
                                   The do-while loop executes the loop body at least _______.
                                    """);
                System.out.print("write your answer");
                answer = input.nextLine();
                if (answer.equalsIgnoreCase(expectedWord)||answer.equalsIgnoreCase("i,j")||answer.equalsIgnoreCase("ij")){
                    System.out.println("Well done!");
                    isCorrect = true;
                    incrementCount();
                }
                else {
                    System.out.print("""
                                     Incorrect :( 
                                     The correct answer is:once
                                     Do you want to Try again or Exit ? (t/e): """);
                    String choice = input.nextLine().toLowerCase();
                    isCorrect = choice.equalsIgnoreCase("e");}
            }while(!isCorrect);
            expectedWord = "9";
            do{
                System.out.println("----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
                System.out.println("""
                                   int sum = 0;
                                   for (int i = 1; i <= 5; i++) {
                                       sum += i;
                                       if (i == 3) {
                                           break;
                                       }
                                   }
                                   System.out.println(sum);
                                   what will be the output?
                                    """);
                System.out.print("write your answer");
                answer = input.nextLine();
                if (answer.equalsIgnoreCase(expectedWord)||answer.equalsIgnoreCase("i,j")||answer.equalsIgnoreCase("ij")){
                    System.out.println("Well done!");
                    isCorrect = true;
                    incrementCount();
                }
                else {
                    System.out.print("""
                                     Incorrect :( 
                                     The correct answer is:9
                                     Do you want to Try again or Exit ? (t/e): """);
                    String choice = input.nextLine().toLowerCase();
                    isCorrect = choice.equalsIgnoreCase("e");}
            }while(!isCorrect);
            expectedWord = "120";
            do{
                System.out.println("----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
                System.out.println("""
                                   int i = 1;
                                   int product = 1;
                                   while (i <= 5) {
                                       product *= i;
                                       i++;
                                   }
                                   System.out.println(product);
                                   what will be the output?
                                    """);
                System.out.print("write your answer");
                answer = input.nextLine();
                if (answer.equalsIgnoreCase(expectedWord)||answer.equalsIgnoreCase("i,j")||answer.equalsIgnoreCase("ij")){
                    System.out.println("Well done!");
                    isCorrect = true;
                    incrementCount();
                }
                else {
                    System.out.print("""
                                     Incorrect :( 
                                     The correct answer is:120
                                     Do you want to Try again or Exit ? (t/e): """);
                    String choice = input.nextLine().toLowerCase();
                    isCorrect = choice.equalsIgnoreCase("e");}
            }while(!isCorrect);






            System.out.println("----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
            System.out.println("Go to next lesson? (y/n)");
            yesOrNo=input.nextLine();
            if(yesOrNo.equalsIgnoreCase("Yes") || yesOrNo.equalsIgnoreCase("yes") || yesOrNo.equalsIgnoreCase("Y") || yesOrNo.equalsIgnoreCase("y")){
                System.out.println("----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
                System.out.println("Lesson 12"+"Arrays");
                System.out.println("----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
                System.out.println("""
                                   Arrays are used to store multiple values in a single variable, instead of declaring separate variables for each value.
                                   To declare an array, define the variable type with square brackets such as : String[] cars;
                                   We have now declared a variable that holds an array of strings. 
                                   To insert values to it, you can place the values in a comma-separated list, inside curly braces:String[] cars = {"Volvo", "BMW", "Ford", "Mazda"};
                                   or int[] myNum = {10, 20, 30, 40}; for integers.
                                   You can access an array element by referring to the index number.
                                   note : Array indexes start with 0: [0] is the first element. [1] is the second element, etc.
                                   This statement accesses the value of the first element in cars:
                                   String[] cars = {"Volvo", "BMW", "Ford", "Mazda"};
                                   System.out.println(cars[0]); Which is Volvo
                                   -To change the value of a specific element, refer to the index number.
                                   -To find out how many elements an array has, use the length property.
                                   -
                                   """);
                expectedWord = "b";
                do{
                    System.out.println("----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
                    System.out.println("""
                                   Which of the following options correctly declares an array of integers in Java?
                                   a) int[] numbers = new int();
                                   b) int[] numbers = new int[5];
                                   c) int numbers = new int[5];
                                   d) int numbers[] = {1, 2, 3, 4, 5};
                                    """);
                    System.out.print("write your answer, only the letter!:");
                    answer = input.nextLine();
                    if (answer.equalsIgnoreCase(expectedWord)){
                        System.out.println("Well done!");
                        isCorrect = true;
                        incrementCount();
                    }
                    else {
                        System.out.print("""
                                     Incorrect :( 
                                     The correct answer is:b
                                     Do you want to Try again or Exit ? (t/e): """);
                        String choice = input.nextLine().toLowerCase();
                        isCorrect = choice.equalsIgnoreCase("e");}
                }while(!isCorrect);
                expectedWord = "0";
                do{
                    System.out.println("----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
                    System.out.println("""
                                   What is the index of the first element in an array?
                                    """);
                    System.out.print("write your answer:");
                    answer = input.nextLine();
                    if (answer.equalsIgnoreCase(expectedWord)||answer.equalsIgnoreCase("zero")){
                        System.out.println("Well done!");
                        isCorrect = true;
                        incrementCount();
                    }
                    else {
                        System.out.print("""
                                     Incorrect :( 
                                     The correct answer is:0
                                     Do you want to Try again or Exit ? (t/e): """);
                        String choice = input.nextLine().toLowerCase();
                        isCorrect = choice.equalsIgnoreCase("e");}
                }while(!isCorrect);
                expectedWord = "length()";
                do{
                    System.out.println("----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
                    System.out.println("""
                                   What method is used to find the length of an array in Java?
                                    """);
                    System.out.print("write your answer:");
                    answer = input.nextLine();
                    if (answer.equalsIgnoreCase(expectedWord)|| answer.equalsIgnoreCase("length")){
                        System.out.println("Well done!");
                        isCorrect = true;
                        incrementCount();
                    }
                    else {
                        System.out.print("""
                                     Incorrect :( 
                                     The correct answer is:length()
                                     Do you want to Try again or Exit ? (t/e): """);
                        String choice = input.nextLine().toLowerCase();
                        isCorrect = choice.equalsIgnoreCase("e");}
                }while(!isCorrect);
                expectedWord = "no";
                do{
                    System.out.println("----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
                    System.out.println("""
                                   Can the size of an array be changed after it is created?
                                    """);
                    System.out.print("write your answer:");
                    answer = input.nextLine();
                    if (answer.equalsIgnoreCase(expectedWord)){
                        System.out.println("Well done!");
                        isCorrect = true;
                        incrementCount();
                    }
                    else {
                        System.out.print("""
                                     Incorrect :( 
                                     The correct answer is:no
                                     Do you want to Try again or Exit ? (t/e): """);
                        String choice = input.nextLine().toLowerCase();
                        isCorrect = choice.equalsIgnoreCase("e");}
                }while(!isCorrect);
                expectedWord = "2";
                do{
                    System.out.println("----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
                    System.out.println("""
                                   To access the element at index 2 in an array named numbers, the syntax would be numbers[ ].
                                   Fill in the blank
                                    """);
                    System.out.print("write your answer:");
                    answer = input.nextLine();
                    if (answer.equalsIgnoreCase(expectedWord)){
                        System.out.println("Well done!");
                        isCorrect = true;
                        incrementCount();
                    }
                    else {
                        System.out.print("""
                                     Incorrect :( 
                                     The correct answer is:2
                                     Do you want to Try again or Exit ? (t/e): """);
                        String choice = input.nextLine().toLowerCase();
                        isCorrect = choice.equalsIgnoreCase("e");}
                }while(!isCorrect);
                System.out.println("----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
                System.out.println("""
                                   Loop Through an Array
                                   You can loop through the array elements with the for loop, and use the length property to specify how many times the loop should run.
                                   Here's an example:
                                   String[] cars = {"Volvo", "BMW", "Ford", "Mazda"};
                                   for (int i = 0; i < cars.length; i++) {
                                     System.out.println(cars[i]);
                                   }
                                   There is also a "for-each" loop, which is used exclusively to loop through elements in arrays
                                   This is an example of it :
                                   String[] cars = {"Volvo", "BMW", "Ford", "Mazda"};
                                   for (String i : cars) {
                                     System.out.println(i);
                                   }
                                   """);
                expectedWord = "a";
                do{
                    System.out.println("----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
                    System.out.println("""
                                   a simple question
                                   int[] numbers = {1, 2, 3, 4, 5};
                                   for (int i = 0; i < numbers.length; i++) {
                                       System.out.print(numbers[i] + " ");
                                   }
                                   What will be the output of the above code
                                   a) 1 2 3 4 5
                                   b) 5 4 3 2 1
                                   c) 1 3 5
                                   d) Compilation error
                                    """);
                    System.out.print("write your answer, only the letter!");
                    answer = input.nextLine();
                    if (answer.equalsIgnoreCase(expectedWord)){
                        System.out.println("Well done!");
                        isCorrect = true;
                        incrementCount();
                    }
                    else {
                        System.out.print("""
                                     Incorrect :( 
                                     The correct answer is:a
                                     Do you want to Try again or Exit ? (t/e): """);
                        String choice = input.nextLine().toLowerCase();
                        isCorrect = choice.equalsIgnoreCase("e");}
                }while(!isCorrect);
                System.out.println("----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
                System.out.println("""
                               Multidimensional Arrays is an array of arrays.
                               To create a two-dimensional array, add each array within its own set of curly braces :
                               int[][] myNumbers = { {1, 2, 3, 4}, {5, 6, 7} };
                               myNumbers is now an array with two arrays as its elements.
                               To access the elements of the myNumbers array, specify two indexes: one for the array, and one for the element inside that array.
                               You can also change the value of an element.
                               We can also use a for loop inside another for loop to get the elements of a two-dimensional array
                               Now let's move on to the questions
                               """);
                System.out.println("----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
                expectedWord = "matrix[i][j]";
                do{
                    System.out.println("----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
                    System.out.println("""
                                   To access the element at row i and column j in a 2D array named matrix, the syntax would be matrix[ ][ ].
                                   Fill the Space
                                    """);
                    System.out.print("write your answer");
                    answer = input.nextLine();
                    if (answer.equalsIgnoreCase(expectedWord)||answer.equalsIgnoreCase("i,j")||answer.equalsIgnoreCase("ij")){
                        System.out.println("Well done!");
                        isCorrect = true;
                        incrementCount();
                    }
                    else {
                        System.out.print("""
                                     Incorrect :( 
                                     The correct answer is:matrix[i][j]
                                     Do you want to Try again or Exit ? (t/e): """);
                        String choice = input.nextLine().toLowerCase();
                        isCorrect = choice.equalsIgnoreCase("e");}
                }while(!isCorrect);









                System.out.println("----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
                System.out.println("Go to next lesson? (y/n)");
                yesOrNo=input.nextLine();
                if(yesOrNo.equalsIgnoreCase("Yes") || yesOrNo.equalsIgnoreCase("yes") || yesOrNo.equalsIgnoreCase("Y") || yesOrNo.equalsIgnoreCase("y")){
                    System.out.println("----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
                    System.out.println("""
                               Lesson 11
                               Methodes""");
                    System.out.println("----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
                    System.out.println("Let's start .");
                    System.out.println("""
                               A method in Java is a block of code that, when called, performs specific actions mentioned in it.
                               An example of a method:
                               
                               public int addNumbers (int a, int b){
                               //method body
                               }
                               
                               1- Access specifier:
                               It is used to define the access type of the method. 
                               *Public: You can access it from any class
                               *Private: You can access it within the class where it is defined
                               *Protected: Accessible only in the same package or other subclasses in another package
                               *Default: It is the default access specifier used by the Java compiler
                               
                               2-ReturnType:
                               It defines the return type of the method. In the above syntax, “int” is the return type.
                               We can mention void as the return type if the method returns no value.
                               
                               3-Method name:
                               It is used to give a unique name to the method. In the above syntax, “addNumbers” is the method name.
                               
                               4-Parameter list:
                               It is a list of arguments (data type and variable name) that will be used in the method.
                               In the above syntax, “int a, int b” mentioned within the parentheses is the parameter list.
                               You can also keep it blank if you don’t want to use any parameters in the method.
                               
                               5- Method signature:
                               The method signature is just a combination of the method name and parameter list.
                               """);
                    System.out.println("----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
                    System.out.println("""
                               Let's start with a simple question :  
                               """);
                    expectedWord = "public";
                    do{
                        System.out.println("----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
                        System.out.println("""
                                   public void greet(String name) {
                                   System.out.println("Hello, " + name + "!");
                                   }
                                   What is the Access Specifier ?""");
                        System.out.print("write your answer here: ");
                        answer = input.nextLine();
                        if (answer.equalsIgnoreCase(expectedWord)){
                            System.out.println("Well done!");
                            isCorrect = true;
                            incrementCount();
                        }
                        else {
                            System.out.print("""
                                     Incorrect :( 
                                     The correct answer is: public ;
                                     Do you want to Try again or Exit ? (t/e): """);
                            String choice = input.nextLine().toLowerCase();
                            isCorrect = choice.equalsIgnoreCase("e");}
                    }while(!isCorrect);

                    expectedWord = "void";
                    do{
                        System.out.println("----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
                        System.out.println("""
                                   public void greet(String name) {
                                   System.out.println("Hello, " + name + "!");
                                   }
                                   What is the Return Type?""");
                        System.out.print("write your answer here: ");
                        answer = input.nextLine();
                        if (answer.equalsIgnoreCase(expectedWord)){
                            System.out.println("Well done!");
                            isCorrect = true;
                            incrementCount();
                        }
                        else {
                            System.out.print("""
                                     Incorrect :( 
                                     The correct answer is: void ;
                                     Do you want to Try again or Exit ? (t/e): """);
                            String choice = input.nextLine().toLowerCase();
                            isCorrect = choice.equalsIgnoreCase("e");}
                    }while(!isCorrect);

                    expectedWord = "greet";
                    do{
                        System.out.println("----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
                        System.out.println("""
                                   public void greet(String name) {
                                   System.out.println("Hello, " + name + "!");
                                   }
                                   What is the Method Name?""");
                        System.out.print("write your answer here: ");
                        answer = input.nextLine();
                        if (answer.equalsIgnoreCase(expectedWord)){
                            System.out.println("Well done!");
                            isCorrect = true;
                            incrementCount();
                        }
                        else {
                            System.out.print("""
                                     Incorrect :( 
                                     The correct answer is: greet ;
                                     Do you want to Try again or Exit ? (t/e): """);
                            String choice = input.nextLine().toLowerCase();
                            isCorrect = choice.equalsIgnoreCase("e");}
                    }while(!isCorrect);

                    expectedWord = "(String name)";
                    do{
                        System.out.println("----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
                        System.out.println("""
                                   public void greet(String name) {
                                   System.out.println("Hello, " + name + "!");
                                   }
                                   What is the Parameter List?""");
                        System.out.print("write your answer here: ");
                        answer = input.nextLine();
                        if (answer.equalsIgnoreCase(expectedWord)){
                            System.out.println("Well done!");
                            isCorrect = true;
                            incrementCount();
                        }
                        else {
                            System.out.print("""
                                     Incorrect :( 
                                     The correct answer is:(String name)  ;
                                     Do you want to Try again or Exit ? (t/e): """);
                            String choice = input.nextLine().toLowerCase();
                            isCorrect = choice.equalsIgnoreCase("e");}
                    }while(!isCorrect);

                    expectedWord = "greet(String name)";
                    do{
                        System.out.println("----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
                        System.out.println("""
                                   public void greet(String name) {
                                   System.out.println("Hello, " + name + "!");
                                   }
                                   What is the Method Signature """);
                        System.out.print("write your answer here: ");
                        answer = input.nextLine();
                        if (answer.equalsIgnoreCase(expectedWord)){
                            System.out.println("Well done!");
                            isCorrect = true;
                            incrementCount();
                        }
                        else {
                            System.out.print("""
                                     Incorrect :( 
                                     The correct answer is:greet(String name) 
                                     Do you want to Try again or Exit ? (t/e): """);
                            String choice = input.nextLine().toLowerCase();
                            isCorrect = choice.equalsIgnoreCase("e");}
                    }while(!isCorrect);

                    System.out.println("----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
                    System.out.println("""
                               you need to call a method to execute and use its functionalities
                               you can call a method by using its name followed by the parentheses and a semicolon just like : add();
                               Methods in Java can be broadly classified into two types:
                               
                               1-Predefined:
                               they can be called and used anywhere in our program without defining them.
                               There are numerous predefined methods, such as length(), sqrt(), max(), and print().
                               1.1-Java Math
                               -Trigonometric Methods :
                               sin(double a),cos(double a),tan(double a),acos(double a),asin(double a),atan(double a)
                               -Exponent Methods:
                               exp(double a):Returns e raised to the power of a.
                               log(double a):Returns the natural logarithm of a.
                               log10(double a):Returns the 10-based logarithm of a.
                               pow(double a, double b):Returns a raised to the power of b.
                               sqrt(double a):Returns the square root of a.
                               -min, max :Returns the maximum or minimum of two parameters.
                               -abs:Returns the absolute value of the parameter
                               -random Methods:Returns a random double value in the range [0.0, 1.0).
                               1.2-Java String
                               length() : Returns the number of characters in this string.     
                               charAt(index): Returns the character at the specified index from this string.
                               concat(s1) : Returns a new string that concatenates this string with string s1. 
                               toUpperCase(): Returns a new string with all letters in uppercase.
                               toLowerCase():Returns a new string with all letters in lowercase.
                               trim(): Returns a new string with whitespace characters trimmed on both sides.
                               
                               
                               2-User-defined:
                               It is possible to modify and tweak these methods according to the situation.
                               
                               """);
                    System.out.println("----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
                    System.out.println("Let's move on to the questions now");
                    expectedWord = "Predefined";
                    do{
                        System.out.println("----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
                        System.out.println("""
                                   String text = "Hello, World!";
                                   System.out.println(text.length());
                                   is length a Predefined method or a User-defined ?
                                   """);
                        System.out.print("write your answer:");
                        answer = input.nextLine();
                        if (answer.equalsIgnoreCase(expectedWord)){
                            System.out.println("Well done!");
                            isCorrect = true;
                            incrementCount();
                        }
                        else {
                            System.out.print("""
                                     Incorrect :( 
                                     The correct answer is: Predefined
                                     Do you want to Try again or Exit ? (t/e): """);
                            String choice = input.nextLine().toLowerCase();
                            isCorrect = choice.equalsIgnoreCase("e");}
                    }while(!isCorrect);
                    expectedWord = "c";
                    do{
                        System.out.println("----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
                        System.out.println("""
                                   String text = "Hello, World!";
                                   int length = text.length();
                                   System.out.println(length);
                                   What will be the output of the above code?
                                   a) 5
                                   b) 12
                                   c) 13
                                   d) 14
                                   """);
                        System.out.print("write your answer,write only the letter :");
                        answer = input.nextLine();
                        if (answer.equalsIgnoreCase(expectedWord)){
                            System.out.println("Well done!");
                            isCorrect = true;
                            incrementCount();
                        }
                        else {
                            System.out.print("""
                                     Incorrect :( 
                                     The correct answer is: c
                                     Do you want to Try again or Exit ? (t/e): """);
                            String choice = input.nextLine().toLowerCase();
                            isCorrect = choice.equalsIgnoreCase("e");}
                    }while(!isCorrect);
                    expectedWord = "c";
                    do{
                        System.out.println("----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
                        System.out.println("""
                                   double x = 4.5;
                                   double y = -2.7;
                                   double result = Math.pow(x, y);
                                   System.out.println(result);
                                   What will be the output of the above code?
                                   a) 0.0
                                   b) 1.0
                                   c) 6.25
                                   d) -6.75
                                   """);
                        System.out.print("write your answer,write only the letter :");
                        answer = input.nextLine();
                        if (answer.equalsIgnoreCase(expectedWord)){
                            System.out.println("Well done!");
                            isCorrect = true;
                            incrementCount();
                        }
                        else {
                            System.out.print("""
                                     Incorrect :( 
                                     The correct answer is: c
                                     Do you want to Try again or Exit ? (t/e): """);
                            String choice = input.nextLine().toLowerCase();
                            isCorrect = choice.equalsIgnoreCase("e");}
                    }while(!isCorrect);
                    expectedWord = "b";
                    do{
                        System.out.println("----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
                        System.out.println("""
                                   double num = -7.8;
                                   double absValue = Math.abs(num);
                                   System.out.println(absValue);
                                   What will be the output of the above code?
                                   a) -7.8
                                   b) 7.8
                                   c) -7.0
                                   d) 7.0
                                   """);
                        System.out.print("write your answer,write only the letter :");
                        answer = input.nextLine();
                        if (answer.equalsIgnoreCase(expectedWord)){
                            System.out.println("Well done!");
                            isCorrect = true;
                            incrementCount();
                        }
                        else {
                            System.out.print("""
                                     Incorrect :( 
                                     The correct answer is: b
                                     Do you want to Try again or Exit ? (t/e): """);
                            String choice = input.nextLine().toLowerCase();
                            isCorrect = choice.equalsIgnoreCase("e");}
                    }while(!isCorrect);
                    System.out.println("----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
                    System.out.println("""
                                   Methods in Java can also be classified into the following types:
                                   1-Static Method :Static methods are the ones that belong to a class and not an instance of a class.It is possible to create a static method by using the “static” keyword.
                                   2-Instance Method:The instance method is a non-static method that belongs to the class and its instance. Creating an object is necessary to call the instance method.
                                   2.1-Accessor Method
                                   It is used to get a private field’s value, accessor methods in Java can only read instance variables. They are always prefixed with the word ‘get’.
                                   2.2-Mutator Method
                                   It is used to get and set the value of a private field, mutator methods in Java can read and modify instance variables. They are always prefixed with the word  ‘set’.
                               here is an example of Accessor and Mutator :
                               public class Person {
                                   private String name;
                                   private int age;
                                   // Getter for name
                                   public String getName() {
                                       return name;
                                   }
                                   // Setter for name
                                   public void setName(String name) {
                                       this.name = name;
                                   }
                                   // Getter for age
                                   public int getAge() {
                                       return age;
                                   }
                                   // Setter for age
                                   public void setAge(int age) {
                                       this.age = age;
                                   }
                               }
                                   """);
                    expectedWord = "no";
                    do{
                        System.out.println("----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
                        System.out.println("""
                                   Is the following method call correct:
                                   myMethod("Hello", 5) (assuming myMethod does not accept two arguments)?
                                   yes or no ?
                                    """);
                        System.out.print("write your answer:");
                        answer = input.nextLine();
                        if (answer.equalsIgnoreCase(expectedWord)){
                            System.out.println("Well done!");
                            isCorrect = true;
                            incrementCount();
                        }
                        else {
                            System.out.print("""
                                     Incorrect :( 
                                     The correct answer is:no 
                                     Do you want to Try again or Exit ? (t/e): """);
                            String choice = input.nextLine().toLowerCase();
                            isCorrect = choice.equalsIgnoreCase("e");}
                    }while(!isCorrect);
                    expectedWord = "c";
                    do{
                        System.out.println("----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
                        System.out.println("""
                                   What is the difference between a static method and an instance method?
                                   a) Static methods can only be called within the same class, while instance methods can be called from other classes.
                                   b) Static methods do not have a return type, while instance methods do.
                                   c) Static methods belong to the class itself, while instance methods belong to individual objects of the class.
                                   d) Static methods can only be used with primitive data types, while instance methods can be used with objects.
                                    """);
                        System.out.print("write your answer, only the letter!:");
                        answer = input.nextLine();
                        if (answer.equalsIgnoreCase(expectedWord)){
                            System.out.println("Well done!");
                            isCorrect = true;
                            incrementCount();
                        }
                        else {
                            System.out.print("""
                                     Incorrect :( 
                                     The correct answer is:c
                                     Do you want to Try again or Exit ? (t/e): """);
                            String choice = input.nextLine().toLowerCase();
                            isCorrect = choice.equalsIgnoreCase("e");}
                    }while(!isCorrect);
                    expectedWord = "c";
                    do{
                        System.out.println("----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
                        System.out.println("""
                                   How do you call a user-defined method in Java?
                                   a) By using the new keyword
                                   b) By importing the method from another class
                                   c) By using the method name followed by parentheses and passing any required arguments
                                   d) By declaring the method as static
                                    """);
                        System.out.print("write your answer, only the letter!:");
                        answer = input.nextLine();
                        if (answer.equalsIgnoreCase(expectedWord)){
                            System.out.println("Well done!");
                            isCorrect = true;
                            incrementCount();
                        }
                        else {
                            System.out.print("""
                                     Incorrect :( 
                                     The correct answer is:c
                                     Do you want to Try again or Exit ? (t/e): """);
                            String choice = input.nextLine().toLowerCase();
                            isCorrect = choice.equalsIgnoreCase("e");}
                    }while(!isCorrect);

                }
                else
                {
                    System.out.println("----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
                    System.out.println("It's good to see you");
                }
                System.out.println("----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
                System.out.println("Thank you for playing!");
                System.out.println("----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");

            }

        }
    }

   /* public void incrementCount() {
        countPointBeg++;
    }
    */
}
